# -*- coding: utf-8 -*-
w = 0.078367
b = 0.401752

def du_doan_gia(dien_tich):
    if dien_tich < 35.5 or dien_tich > 117.5:
        print(f"Canh bao: dien tich {dien_tich} m2 nam ngoai khoang du lieu.")

    gia_du_doan = w * dien_tich + b
    return gia_du_doan

dien_tich_1 = 60
dien_tich_2 = 80
dien_tich_3 = 200

gia_1 = du_doan_gia(dien_tich_1)
gia_2 = du_doan_gia(dien_tich_2)
gia_3 = du_doan_gia(dien_tich_3)

print(f"Can {dien_tich_1} m2 -> {gia_1:.3f} ty dong")
print(f"Can {dien_tich_2} m2 -> {gia_2:.3f} ty dong")
print(f"Can {dien_tich_3} m2 -> {gia_3:.3f} ty dong")
