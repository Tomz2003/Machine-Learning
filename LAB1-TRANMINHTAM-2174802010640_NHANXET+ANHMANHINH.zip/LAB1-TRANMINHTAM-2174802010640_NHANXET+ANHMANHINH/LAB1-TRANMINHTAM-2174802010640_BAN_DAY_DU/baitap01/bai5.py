# -*- coding: utf-8 -*-
import numpy as np
import pandas as pd

df = pd.read_csv("data/gia_nha.csv")

x_goc = df["dien_tich"].to_numpy()
y = df["gia"].to_numpy()

x_tb = x_goc.mean()
x_do_lech = x_goc.std()
x = (x_goc - x_tb) / x_do_lech

so_vong = 200
n = len(x)

def chay_gradient_descent(toc_do_hoc):
    w = 0.0
    b = 0.0

    for vong in range(1, so_vong + 1):
        y_du_doan = w * x + b
        chenh_lech = y_du_doan - y

        grad_w = (2 / n) * (chenh_lech * x).sum()
        grad_b = (2 / n) * chenh_lech.sum()

        w -= toc_do_hoc * grad_w
        b -= toc_do_hoc * grad_b

    y_cuoi = w * x + b
    mse = ((y - y_cuoi) ** 2).mean()
    return mse

mse_001 = chay_gradient_descent(0.001)
mse_102 = chay_gradient_descent(1.02)

print(f"MSE voi toc do hoc 0.001: {mse_001:.4f}")
print(f"MSE voi toc do hoc 1.02 : {mse_102:.4f}")
print("Giai thich: 0.001 qua nho nen cap nhat rat cham; 1.02 qua lon nen buoc nhay vuot qua diem toi uu va MSE tang rat nhanh.")
