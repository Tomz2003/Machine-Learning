# -*- coding: utf-8 -*-
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("data/gia_nha.csv")

plt.figure(figsize=(8, 5))
plt.scatter(df["so_phong"], df["gia"])
plt.xlabel("So phong")
plt.ylabel("Gia (ty dong)")
plt.title("Bieu do phan tan giua so phong va gia")
plt.grid(alpha=0.25)
plt.savefig("bai2.png", dpi=150, bbox_inches="tight")
plt.show()

print("Nhan xet: Gia can ho co xu huong tang khi so phong tang, tuy nhien cac diem du lieu van co su phan tan.")
