# -*- coding: utf-8 -*-
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score

df = pd.read_csv("data/gia_nha.csv")

X = df[["dien_tich", "so_phong"]]
y = df["gia"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

mo_hinh = LinearRegression()
mo_hinh.fit(X_train, y_train)

y_du_doan = mo_hinh.predict(X_test)
r2 = r2_score(y_test, y_du_doan)

print(f"R2 tren tap kiem tra = {r2:.4f}")
print("R2 mo hinh mot bien = 0.9622")
print("Nhan xet: Khi them so phong, R2 tang tu 0.9622 len khoang 0.9698.")
print("Muc tang khong qua lon nhung mo hinh da tot hon mot chut.")
