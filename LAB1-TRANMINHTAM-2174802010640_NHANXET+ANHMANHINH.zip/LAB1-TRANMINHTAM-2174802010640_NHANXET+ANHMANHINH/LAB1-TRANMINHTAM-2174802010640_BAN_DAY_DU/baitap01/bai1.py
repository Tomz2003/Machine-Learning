# -*- coding: utf-8 -*-
import pandas as pd

df = pd.read_csv("data/gia_nha.csv")

nhom_lon = df[df["dien_tich"] > 100]
so_can = len(nhom_lon)
gia_trung_binh = nhom_lon["gia"].mean()

print("So can co dien tich > 100 m2:", so_can)
print(f"Gia trung binh: {gia_trung_binh:.3f} ty dong")
